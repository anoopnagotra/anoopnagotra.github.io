# Center-logo-in-navbar
Center logo in navbar Perfect Coding (Most people do it the wrong way). Most of the time if the logo is in center lt looks much better than then topical left or right align logo. However, I found most people do it the wrong way. Therefore, I create this tutorial. If you are interested to create a logo in the right way, continue this tutorial. 

🔴 Center logo in navbar Perfect Coding
==============================================
https://www.youtube.com/watch?v=hp-LP8Nv18s


🔴 Center logo in Responsive Navigation Bar | Part 2
============================================================
https://www.youtube.com/watch?v=svv7jOxaSzw
